package com.blancharddero.pendu;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;

public abstract class Session {
    
    private String host;

    public Session(String user){
        this.host = user;
    }

    public abstract void startSession(Socket s, ObjectOutputStream oos, ObjectInputStream ois, HashMap<String, Object> parameters);

    public String getHost(){
        return host;
    }

}
