package com.blancharddero;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.ClassNotFoundException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import com.blancharddero.pendu.Session;
import com.blancharddero.pendu.SessionMulti;
import com.blancharddero.pendu.SessionSolo;

/**
 * This class uses java Socket server to connection tentatives and the creation of Sessions to play the game of Hangman
 */
public class ServerPendu {

    // Sockets declaration
    private static ServerSocket server;
    private static DatagramSocket connectionSocket;

    // Buffer pour la connexion UDP
    final static int taille = 1024;
    final static byte buffer[] = new byte[taille];

    // Server parameters
    private static Map<String, Long> authorizedUsers = new HashMap<>(); // The user connected via UDP and authorized for TCP connection for a limited time
    private static final int TIMEOUT = 5000; // How long the server wait before timout for TCP connection.
    private static final int MAX_THREADS = 10; // Maximum number of threads on the server at the same time
    private static ExecutorService threadPool;
    private static Map<String, SessionMulti> multiplayer_sessions = new HashMap<String, SessionMulti>();


    // Runnable representing a TCP dialogue between the Client and the Server
    public static class clientServerConnection implements Runnable{

        // Client's Info
        private Socket socket;
        ObjectOutputStream oos;
        ObjectInputStream ois;
        String roomName = "";

        public clientServerConnection(Socket s) {
            this.socket = s;
        }

        public void run() {

            try{
                //create ObjectOutputStream object
                oos = new ObjectOutputStream(socket.getOutputStream());
                //read from socket to ObjectInputStream object
                ois = new ObjectInputStream(socket.getInputStream());

                // Loop in the main Menu
                while (!socket.isClosed()) {

                    /**
                     * Read the Client's choosed game mode
                     * The possible arguments of the map are:
                     * "mode": To choose between a singleplayer or multiplayer Session
                     * "action": To choose between joining or creating a multiplayer Session
                     * "username": The username of the client
                     * "roomName": In case of creating a multiplayer Session, the name of the room
                     * "roomPassword": In case of creating a multiplayer Session, the password of the room, "" if no password
                     * "parameters": In case of a Singleplayer Session, the parameters of a game
                     * */
                    @SuppressWarnings("unchecked") // Possible error managed by try-catch
                    HashMap<String, Object> typeSession = (HashMap<String, Object>) ois.readObject();

                    // If the mode is single then start a Solo Game Session
                    if (typeSession.get("mode").equals("single")) {
                        Session session = new SessionSolo((String)typeSession.get("username"));
                        session.startSession(socket, oos, ois, typeSession);
                    } else {
                        // Else look if the client wants to join or create a multiplayer Session
                        switch (typeSession.get("action").toString()) {
                            case "join": // The client wants to join
                                oos.writeObject(getSessions());

                                while(!socket.isClosed()){

                                    /**
                                     * Receive the choice of the client
                                     * The possible arguments of the map are:
                                     * "action": To refresh the selection of Sessions or cancel to go back to main menu
                                     * "roomName": The name of the room the client desire to connect
                                     * "roomPass": The Password for that room, "" if none
                                     */
                                    @SuppressWarnings("unchecked") // Possible error managed by try-catch
                                    HashMap<String, String> choice = (HashMap<String, String>) ois.readObject();

                                    // Check if client's choice is to refresh the selection or to cancel and go back to the main menu
                                    if(choice.get("action") != null){
                                        if (choice.get("action").equals("refresh")) {
                                            oos.writeObject(getSessions());
                                            continue;
                                        } else if (choice.get("action").equals("cancel")){
                                            oos.writeObject("canceling");
                                            break;
                                        }
                                    }

                                    // Test if the client inputed the right room password
                                    if(multiplayer_sessions.get(choice.get("roomName")).testPassword(choice.get("roomPass"))){
                                        if (!choice.get("roomPass").equals("")){
                                            oos.writeObject("Yes");
                                            if (ois.readObject() != null) throw new Error("Received message should be null");
                                        }

                                        // Add the client to the Session of another client
                                        multiplayer_sessions.get(choice.get("roomName")).addPlayer((String)typeSession.get("username"), ois, oos, socket);

                                        // Make the client wait while they are in the game
                                        synchronized(socket){
                                            socket.wait();
                                        }
                                    } else oos.writeObject("No");

                                }
                                break;

                            case "create": // The client wants to create a new Session
                                // Create a new multiplayer Session with the client as Host and add it to the list of multiplayer sessions
                                roomName = (String)typeSession.get("roomName");
                                multiplayer_sessions.put((String)typeSession.get("roomName"), new SessionMulti((String)typeSession.get("username")));
                                multiplayer_sessions.get((String)typeSession.get("roomName")).startSession(socket, oos, ois, typeSession);
                                break;

                            default:
                                break;
                        }
                    }
                    //System.out.println("\n\n" + socket.getInetAddress().getHostAddress() + " : Session started");

                }

            } catch(IOException|ClassNotFoundException | InterruptedException e){
                e.printStackTrace();
                System.out.println("##ERROR##" + socket.getInetAddress() + ": Error in the main Menu");
            } finally {
                multiplayer_sessions.remove(roomName);
                //close resources
                try {
                    ois.close();
                    oos.close();
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static HashMap<String, Object> getSessions(){
        HashMap<String, Object> data = new HashMap<>();

        // Send the list of available Rooms
        multiplayer_sessions.forEach((key, value) -> {
            data.put(value.getRoomName(), Map.of("password", (value.isPasswordNull()?"":"True"), "maxPlayer", value.getMaxPlayer(), "nbPlayer", value.getNbActivePlayer(), "nbWaiting", value.getNbWaitingPlayer(), "host", value.getHost()));
        });

        return data;
    }


    public static void main(String args[]) {
        // socket server port on which it will listen
        int portTCP = 4570;
        int portUDP = 9518;

        try {
            // The ThreadPool to manage the number of threads active at the same time
            threadPool = Executors.newFixedThreadPool(MAX_THREADS);

            // Sockets creation
            server = new ServerSocket(portTCP);
            connectionSocket = new DatagramSocket(portUDP);

            // keep listening indefinitely until program terminates
            // create a thread for each client connected
            while(true){
                System.out.println("---\n\nWaiting for the client connection attempt...");

                // Waiting Connection via UDP
                DatagramPacket data = new DatagramPacket(buffer,buffer.length);
                connectionSocket.receive(data);

                System.out.println("\n\nClient trying to connect");

                // Starts a thread to handle the connexion
                threadPool.execute(() -> handleUDPRequest(connectionSocket, server, data));
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            System.out.println("---\n\nSHUTTING DOWN SERVER\n\n---");
            threadPool.shutdownNow();
            // Closing Sockets
            if (connectionSocket != null && !connectionSocket.isClosed()) {
                connectionSocket.close();
            }
            if (server != null && !server.isClosed()) {
                try {
                    server.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            // Closing the ThreadPool
            threadPool.shutdown();
            try {
                if (!threadPool.awaitTermination(60, TimeUnit.SECONDS)) {
                    threadPool.shutdownNow();
                }
            } catch (InterruptedException ex) {
                threadPool.shutdownNow();
            }
        }
    }

    /**
     * Used to handle one tentatives of UDP connection
     * @param connectionSocket The Datagram Socket
     * @param server The Socket of the Server
     * @param data The DatagramPacket
     */
    private static void handleUDPRequest(DatagramSocket connectionSocket, ServerSocket server, DatagramPacket data) {
        try {
            // Getting client's message and IP
            String clientMessage = new String(data.getData(), 0, data.getLength());
            String clientIP = data.getAddress().getHostAddress();

            // Verification of client's credentials
            if (ManipulationFichiers.connectionJoueur(clientMessage)) {
                // Send "OK" to client
                data.setData("OK".getBytes());
                connectionSocket.send(data);

                // User with this IP can connect to the server via TCP for a limited time
                authorizedUsers.put(clientIP, System.currentTimeMillis());
                System.out.println("\n\nUser from IP " + clientIP + " is authorized to connect via TCP.");

                // Handle the TCP connection and create a new thread to manage the succesful connection
                handleTCPConnection(clientIP, server);
            } else {
                // Send "NO" to client
                System.out.println("\n\n" + clientIP + " failed to connect.");
                data.setData("NO".getBytes());
                connectionSocket.send(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Used to handle the TCP connection and create a new thread for managing it.
     * Wait for some time before a timeout
     * @param clientIP The client's IP used for information in the prints
     * @param server The socket of the server
     */
    private static void handleTCPConnection(String clientIP, ServerSocket server) {
        try {
            // Imposer un délai d'attente pour la connexion TCP
            server.setSoTimeout(TIMEOUT);
            System.out.println("\n\nWaiting for TCP connection from " + clientIP);

            // Waiting TCP connection
            Socket socket = server.accept();
            String socketIP = socket.getInetAddress().getHostAddress();

            // Vérifier si l'adresse IP de la connexion TCP correspond à celle d'un des utilisateur autorisé via UDP
            if (authorizedUsers.containsKey(socketIP) && (System.currentTimeMillis() - authorizedUsers.get(socketIP)) < TIMEOUT) {
                // Créer un thread pour le client connecté
                Thread client = new Thread(new clientServerConnection(socket));
                client.start();
                System.out.println("\n\nTCP connection accepted from " + socketIP);
            } else {
                System.out.println("\n\nUnauthorized TCP connection attempt from " + socketIP);
                socket.close(); // Fermer la connexion si non autorisée
            }

            authorizedUsers.remove(socketIP); // Retirer l'utilisateur de la liste autorisée
        } catch (SocketTimeoutException e) {
            System.out.println("\n\nTCP connection timeout for " + clientIP + "\n\n---");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
