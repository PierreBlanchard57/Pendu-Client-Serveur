package com.blancharddero.pendu;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class SessionSolo extends Session{

    private Socket sock;
    private ObjectOutputStream oos; 
    private ObjectInputStream ois;
    ScheduledExecutorService scheduler;

    BlockingQueue<Object> queue = new LinkedBlockingQueue<>();
    Boolean senderThreadActive = true;

    public SessionSolo(String user) {
        super(user);
    }

    @Override
    // Session to play alone with the server
    public void startSession(Socket s, ObjectOutputStream output, ObjectInputStream input, HashMap<String, Object> parameters) {

        sock = s;
        oos = output;
        ois = input;
        Boolean first = true;

        HashMap<String, Object> message = null;
        while (sock.isConnected()) {
            // Waiting for Game object
            try {

                if(!first){
                    message=(HashMap<String, Object>) ois.readObject();
                    if(message.get("update") != null) break;
                }

                Game game = new Game(parameters);
                System.out.println(getHost() + " started a solo game");
                first = false;

                // Start a game
                startGame(game);

            } catch (ClassNotFoundException | IOException e) {
                e.printStackTrace();
                closeAll();
                break;
            }
        }
    }

    /**
     * Return the HashMap filled with the data of the Game required to update all of the clients
     * @param g The game to get the data from
     * @return the HashMap filled with the data of the Game required to update all of the clients
     */
    private HashMap<String, Object> getDataToSend(Game g){

        // Prepare the data to send
        HashMap<String, Object> dataToSend = new HashMap<String, Object>();
        dataToSend.put("lives", g.getLives());
        dataToSend.put("word", g.getCurrentWord());
        dataToSend.put("timer", g.getTimer());

        return dataToSend;

    }

    private void startGame(Game g){

        try {
            // Choose the word from the database
            g.initiateWord();
            String letter;

            // Define the Scheduled services
            scheduler = Executors.newScheduledThreadPool(2);

            //Send back the empty word
            System.out.println("Message choisit : " + g.getWord());
            queue.add(getDataToSend(g));

            // Writer thread that handles all writes
            Thread writer = new Thread( () -> { 
                try {
                    while (senderThreadActive) {
                        Object obj = queue.take(); // Blocks until there is an object to send
                        synchronized (oos) {
                            oos.writeObject(obj);
                            oos.flush();
                        }
                    }
                    
                } catch (IOException | InterruptedException e) {
                    e.getMessage();
                    System.out.println("Error when sending updated game to " + getHost());
                    closeAll();
                }
            });
            senderThreadActive = true;
            writer.start();

            // Start the timer to decrement time every second
            if (g.isTimed()) {
                scheduler.scheduleAtFixedRate(() -> {
                    g.decreaseTimer();
                    if (g.getTimer() <= 0) {
                        System.out.println(getHost() + ": Time's up!");
                        queue.add(getDataToSend(g));
                    }
                }, 1, 1, TimeUnit.SECONDS);
            }

            // Start another task to send game state every 5 seconds
            scheduler.scheduleAtFixedRate(() -> {
                queue.add(getDataToSend(g));
            }, 5, 5, TimeUnit.SECONDS);

            // Main loop of the game
            while (!sock.isClosed()) {
                // Receive letter
                System.out.println(getHost() + ": Waiting letter...");
                letter = (String) ois.readObject();

                // Call updateUsedLetters with the received letter
                if(letter != null) g.updateUsedLetters(letter);
                System.out.println(getHost() + ": " + g.getCurrentWord() + " lives: " + g.getLives());

                // Exit the game loop if the word is found or lives/timer are depleted
                if (g.isEnded()) break;

                // Send the updated game
                queue.add(getDataToSend(g));

            }

            if (g.getLives() < 0 || (g.getTimer() <= 0 && g.isTimed())) {
                System.out.println(getHost() + ": Partie Perdue !");
            } else System.out.println(getHost() + "Partie Gagné !");

            // Send the final state of the game with the completed word
            HashMap<String, Object> data = getDataToSend(g);
            data.replace("word", g.getWord());
            queue.add(data);

            // Shutdown threads used for the game
            scheduler.shutdown();
            scheduler.awaitTermination(500, TimeUnit.MILLISECONDS);
            senderThreadActive = false;

        } catch (ClassNotFoundException | IOException | InterruptedException e) {
            e.printStackTrace();
            closeAll();
        }
    }

    // Close all ressources in case of an error
    private void closeAll(){
        try {
            System.out.println(getHost() + ": Closing Session Solo");
            scheduler.shutdownNow();
            senderThreadActive = false;
            ois.close();
            oos.close();
            sock.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
