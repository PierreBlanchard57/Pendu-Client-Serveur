package com.blancharddero.pendu;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public class SessionMulti extends Session{

    // Information about the host
    private Socket sock;
    private ObjectOutputStream oos;
    private ObjectInputStream ois;

    // Information about the room
    private String roomName;
    private String roomPassword;
    private boolean inGame;
    private int maxPlayer;

    // Lists of the logged players
    private Map<String, Map<String, Object>> players;
    // Lists of the logged players waiting next round
    private Map<String, Map<String, Object>> waitingPlayers;

    // Name of the player whose turn it is to play.
    private String playerToPlay;
    private String lastLetter = null;

    // Thread variables
    Boolean senderThreadActive = true;
    ScheduledExecutorService scheduler;
    BlockingQueue<Object> queue = new LinkedBlockingQueue<>();

    /**
     * Constructor of a multiplayer Session
     * @param user The host of this multiplayer Session
     */
    public SessionMulti(String user){
        super(user);
        players = new HashMap<>();
        waitingPlayers = new HashMap<>();
        inGame = false;
        maxPlayer = 4;
    }

    /**
     * If there is not the maximum of player in the room: Add a new player in the room or the waiting list if the room is in game
     * @param playerName The pseudo of the player
     * @param oisPlayer The Input Stream of the added player
     * @param oosPlayer The Output Stream of the added player
     * @param s The player's connexion socket
     * @return True if added then False
     **/
    public Boolean addPlayer(String playerName, ObjectInputStream oisPlayer, ObjectOutputStream oosPlayer, Socket s){
        // Check if room is full
        if (players.size() + waitingPlayers.size() >= maxPlayer) return false;

        // Add the new player
        HashMap<String, Object> playerInfo = new HashMap<String, Object>();
        playerInfo.put("ois", oisPlayer);
        playerInfo.put("oos", oosPlayer);
        playerInfo.put("socket", s);
        (inGame?waitingPlayers:players).put(playerName, playerInfo);

        // Send the updated list of players
        HashMap<String, Object> data = new HashMap<>();
        data.put("players", new ArrayList<String>(players.keySet()));
        data.put("update", "players");
        queue.add(data);

        return true;
    }

    /**
     * Add waiting players to the list of active players
     */
    private void activateWaintingPlayers(){
        players.putAll(waitingPlayers);
    }

    /**
     * Remove a player from the room
     * @param p The pseudo of the player to disconnect
     */
    private void disconnectPlayer(String p){
        // Notify the waiting socket of the player and remove them from the room
        Socket s = (Socket)players.get(p).get("socket");
        synchronized(s){
            if (players.containsKey(p)) {
                s.notify();
                players.remove(p);
            }else {
                s.notify();
                waitingPlayers.remove(p);
            }
        }


        // if there are no active players left in the room while a game is taking place, try to activate some waiting player
        //or if there is no waiting players close the session because the game cannot continue.
        if (players.size() == 0 && inGame) {
            if(waitingPlayers.size()==0 && inGame) closeAll();
            else activateWaintingPlayers();
        }

        // Send the updated list of players
        HashMap<String, Object> data = new HashMap<>();
        data.put("players", players.keySet());
        data.put("update", "players");
        queue.add(data);
    }

    /**
     * Send an update to all player
     * @param dataToSend The data to be sended
     */
    private void broadcastUpdate(Object dataToSend){
        synchronized(players){
            players.forEach((key, value) -> {
                try {
                    ((ObjectOutputStream)value.get("oos")).writeObject(dataToSend);
                } catch (IOException e) {
                    e.printStackTrace();
                    System.out.println("Connexion error when sending update to: "+key);
                    disconnectPlayer(key);
                }
            });
        }
        try {
            if(!sock.isClosed()) oos.writeObject(dataToSend);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Connexion error when sending update to Host: "+getHost());
            closeAll();
        }
    }

    /**
     * Return the HashMap filled with the data of the Game required to update all of the clients
     * @param g The game to get the data from
     * @return the HashMap filled with the data of the Game required to update all of the clients
     */
    private HashMap<String, Object> getGameDataToSend(Game g){

        // Prepare the data to send
        HashMap<String, Object> dataToSend = new HashMap<String, Object>();
        dataToSend.put("lives", g.getLives());
        dataToSend.put("word", g.getCurrentWord());
        dataToSend.put("timer", g.getTimer());
        dataToSend.put("currentPlayer", playerToPlay);
        dataToSend.put("update", "game");
        dataToSend.put("letter", lastLetter);
        if (lastLetter != null) lastLetter = null;
        return dataToSend;
    }

    @Override
    public void startSession(Socket s, ObjectOutputStream output, ObjectInputStream input, HashMap<String, Object> parameters) {

        // Inform the Host about the creation of the room
        try {
            output.writeObject("ok");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("##ERROR## " + getHost() + ": Error when sending room creation message to Host");
            closeAll();
        }

        // Save the host's communication objects
        sock = s;
        oos = output;
        ois = input;

        // Extract the name and password of the room
        roomName = (String) parameters.get("roomName");
        roomPassword = (String) parameters.get("roomPassword");
        if (roomPassword == null) roomPassword = "";

        // Start the writer thread
        // Writer thread that handles all writes
        Thread writer = new Thread( () -> {
            try {
                while (senderThreadActive) {
                    Object obj = queue.take(); // Blocks until there is an object to send
                    broadcastUpdate(obj);
                }

            } catch (InterruptedException e) {
                e.printStackTrace();
                System.out.println("##ERROR## " + getHost() + ": Error when waiting update from the queue");
                closeAll();
            }
        });
        writer.start();

        // Loop in the room to come back in it after a game
        while (sock.isConnected()) {
            inGame = false;

            // Wait to receive the game's info to start the game with all connected players
            try {
                @SuppressWarnings("unchecked") // Possible error managed by try-catch
                HashMap<String, Object> gameInfo = (HashMap<String, Object>) ois.readObject();
                System.out.println(getHost() + ": started a multiplayer game");
                inGame = true;
                startGame(new Game(gameInfo));

            } catch (ClassNotFoundException | IOException e) {
                e.printStackTrace();
                System.out.println("##ERROR## " + getHost() + ": error when receiving the game info from Host");
                closeAll();
            }



        }
    }

    private void startGame(Game g){

        try {
            String letter;

            // Define the Scheduled services
            scheduler = Executors.newScheduledThreadPool(2);

            // Start the timer to decrement time every second
            if (g.isTimed()) {
                scheduler.scheduleAtFixedRate(() -> {
                    g.decreaseTimer();
                    if (g.getTimer() <= 0) {
                        System.out.println(getHost() + ": Time's up!");
                        inGame = false;
                        queue.add(getGameDataToSend(g));
                    }
                }, 1, 1, TimeUnit.SECONDS);
            }

            // Start another task to send game state every 5 seconds
            scheduler.scheduleAtFixedRate(() -> {
                if (g.isTimed() && g.getTimer() <=0) return;
                queue.add(getGameDataToSend(g));
            }, 5, 5, TimeUnit.SECONDS);

            // Main loop of the game
            while (inGame) {

                // for each active players
                for (String player: players.keySet()){
                    playerToPlay = player;

                    // Broadcast the game's state due to the new playerToPlay
                    broadcastUpdate(getGameDataToSend(g));

                    try {
                        // Receive letter
                        System.out.println("Waiting letter...");
                        letter = (String) ((ObjectInputStream) players.get(player).get("ois")).readObject();
                        lastLetter = letter;

                        // Call updateUsedLetters with the received letter
                        g.updateUsedLetters(letter);

                    } catch (ClassNotFoundException | IOException e) {
                        e.printStackTrace();
                        System.out.println("##ERROR## while waiting response from " + player);
                        disconnectPlayer(player);
                    }

                    System.out.println(g.getCurrentWord() + " lives: " + g.getLives());

                    // Exit if the word is found or lives are depleted
                    if (g.isEnded()) break;

                }

                // Exit if the word is found or lives are depleted
                if (g.isEnded()) inGame = false;

            }

            if (g.getLives() < 0 || (g.getTimer() <= 0 && g.isTimed())) {
                System.out.println(getHost() + ": Mot non trouvé !");
            } else System.out.println(getHost() + ": Mot trouvé !");

            // Send the final state of the game with the completed word
            HashMap<String, Object> data = getGameDataToSend(g);
            data.replace("word", g.getWord());
            queue.add(data);

            // Shutdown threads used for the game
            scheduler.shutdown();
            scheduler.awaitTermination(500, TimeUnit.MILLISECONDS);
            senderThreadActive = false;

        } catch (InterruptedException e) {
            e.printStackTrace();
            closeAll();
        }
    }

    /**
     * In case of fatal error or Host's disconnection
     * Close all ressources, disconnect players and inform all players
     */
    private void closeAll(){
        try {
            System.out.println(getHost() + ": Closing Multiplayer Session");
            inGame = false;

            // Inform all players
            activateWaintingPlayers();
            HashMap<String, Object> closingMessage = new HashMap<>();
            closingMessage.put("update", "closing");
            broadcastUpdate(closingMessage);

            // Disconnect them all
            players.forEach((key, value) -> {
                disconnectPlayer(key);
            });

            scheduler.shutdownNow();
            ois.close();
            oos.close();
            sock.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getRoomName(){
        return roomName;
    }

    public int getMaxPlayer(){
        return maxPlayer;
    }

    public int getNbActivePlayer(){
        return players.size();
    }

    public int getNbWaitingPlayer(){
        return waitingPlayers.size();
    }

    public boolean isPasswordNull(){
        return roomPassword.equals("");
    }

    public Boolean testPassword(String pass){
        return roomPassword.equals(pass);
    }
}